export class Examen{
    public idExamen: number;
    public nombre: string;    
    public descripcion: string;    
}