package com.mitocode.service;

import com.mitocode.model.Medico;

public interface IMedicoService extends ICRUD<Medico, Integer>{


}
