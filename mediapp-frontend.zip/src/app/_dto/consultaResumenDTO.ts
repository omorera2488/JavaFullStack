export class ConsultaResumenDTO {
    cantidad: number;
    fecha: string;
}